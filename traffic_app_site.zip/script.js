
function addReport() {
    const input = document.getElementById('reportInput');
    const reportList = document.getElementById('reportList');

    if (input.value.trim() !== "") {
        const li = document.createElement('li');
        li.textContent = input.value;
        reportList.appendChild(li);
        input.value = "";
    }
}
